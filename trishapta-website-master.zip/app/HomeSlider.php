<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomeSlider extends Model
{
    protected $fillable = ['title','alt','product_link','order','status'];

}
