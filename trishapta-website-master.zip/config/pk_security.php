<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 3/9/2018
 * Time: 11:58 AM
 */
return [

    'url' => [
        'frontend' => [
            'image' => 'assets/uploads/images/'
        ],
        'backend' => [
            'image' => 'assets/uploads/images/'
        ],

    ],

    'mail' => [
        'info' => 'info@trishapta.com'
    ]
];